
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { createClient } from '@supabase/supabase-js';

// നിങ്ങൾ നൽകിയ വിവരങ്ങൾ ഇവിടെ കൃത്യമായി ചേർത്തിട്ടുണ്ട്.
// 1st: URL, 2nd: Anon Key.

const supabaseUrl = 'https://ctiidqordganafncacjo.supabase.co'; 

const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN0aWlkcW9yZGdhbmFmbmNhY2pvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwNjQzMjksImV4cCI6MjA3NzY0MDMyOX0.EV-qdj6lfOKSfrYDv-_HIT7szPx16iWaQc91yrtx-J0';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
