
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { supabase } from './supabaseClient';
import { View, Product, CartItem, Order, Language, ShippingAddress } from './types';
import { CATEGORIES, TRANSLATIONS, CATEGORY_MAP } from './constants';

// --- Icons ---
const HomeIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
const CartIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>;
const SearchIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
const BellIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>;
const PlusIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
const TrashIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>;
const ArrowLeftIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>;
const GearIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>;

const CAT_IMAGES: Record<string, string> = {
  "Women Ethnic": "https://img.icons8.com/color/96/sari.png",
  "Women Western": "https://img.icons8.com/color/96/dress.png",
  "Men": "https://img.icons8.com/color/96/shirt.png",
  "Kids": "https://img.icons8.com/color/96/teddy-bear.png",
  "Home & Kitchen": "https://img.icons8.com/color/96/kitchen.png",
  "Electronics": "https://img.icons8.com/color/96/smartphone.png",
  "All": "https://img.icons8.com/color/96/shopping-basket-add.png"
};

function App() {
  const [isSplashActive, setIsSplashActive] = useState(true);
  const [view, setView] = useState<View>('home');
  const [lang, setLang] = useState<Language>('ml');
  const [products, setProducts] = useState<Product[]>([]);
  const [banners, setBanners] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminPass, setAdminPass] = useState("");
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'Online'>('COD');
  const [userOrders, setUserOrders] = useState<any[]>([]);
  const [searchPhone, setSearchPhone] = useState("");
  const [adminUpi, setAdminUpi] = useState("9656157582@ybl");
  const [adminTab, setAdminTab] = useState<'orders' | 'products' | 'banners' | 'settings'>('orders');

  const bannerRef = useRef<HTMLInputElement>(null);
  const productGalleryRef = useRef<HTMLInputElement>(null);
  
  const [newProd, setNewProd] = useState({ 
    name: '', price: '', category: 'Women Ethnic', subCategory: 'Sarees', 
    images: [] as string[], description: '', sizes: [] as string[] 
  });

  const [address, setAddress] = useState<ShippingAddress>({
    fullName: '', phoneNumber: '', houseNo: '', area: '', pincode: '', city: '', state: '', landmark: ''
  });

  const t = TRANSLATIONS[lang];

  const fetchData = async () => {
    try {
      const [prodRes, bannerRes] = await Promise.all([
        supabase.from('products').select('*').order('created_at', { ascending: false }),
        supabase.from('banners').select('*').order('created_at', { ascending: false })
      ]);
      setProducts(prodRes.data || []);
      setBanners(bannerRes.data || []);
      
      const { data: upiData } = await supabase.from('settings').select('*').eq('id', 'admin_upi').single();
      if (upiData) setAdminUpi(upiData.value);
    } catch (err) { console.error(err); }
  };

  const fetchAdminOrders = async () => {
    const { data } = await supabase.from('orders').select('*').order('created_at', { ascending: false });
    setOrders(data || []);
  };

  useEffect(() => {
    fetchData();
    const timer = setTimeout(() => setIsSplashActive(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleAddToCart = (product: Product) => {
    const newItem: CartItem = { ...product, quantity: 1, selectedSize, selectedColor };
    setCart([...cart, newItem]);
    alert("കാർട്ടിലേക്ക് ചേർത്തു!");
  };

  const handlePlaceOrder = async () => {
    if(!address.fullName || !address.phoneNumber || !address.pincode || !address.houseNo) { alert("ദയവായി എല്ലാ വിവരങ്ങളും നൽകുക!"); return; }
    
    const total = cart.reduce((a, b) => a + b.price, 0);
    
    if (paymentMethod === 'Online') {
        const upiUrl = `upi://pay?pa=${adminUpi}&pn=KHALSAre&am=${total}&cu=INR`;
        window.location.href = upiUrl;
    }

    try {
      const { error } = await supabase.from('orders').insert([{
        items: JSON.stringify(cart), 
        total: total,
        shipping_address: address,
        payment_method: paymentMethod,
        status: 'Pending'
      }]);
      if (error) throw error;
      alert("ഓർഡർ സ്വീകരിച്ചു!");
      setCart([]);
      setView('home');
    } catch (err) { alert("ഓർഡർ സേവ് ചെയ്യുന്നതിൽ പരാജയപ്പെട്ടു."); }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
      await supabase.from('orders').update({ status: newStatus }).eq('id', orderId);
      fetchAdminOrders();
  };

  const handleAdminLogin = () => {
    if (adminPass === "admin123") {
        setIsAdminLoggedIn(true);
        fetchAdminOrders();
    } else {
        alert("Incorrect Password!");
    }
  };

  const handleBannerUpload = async (e: any) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = async () => {
            const base64 = reader.result as string;
            await supabase.from('banners').insert([{ image: base64 }]);
            fetchData();
        };
        reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = async () => {
      if(!newProd.name || !newProd.price || newProd.images.length === 0) return alert("പൂർണ്ണമായി നൽകുക!");
      await supabase.from('products').insert([{
          name: newProd.name,
          price: parseFloat(newProd.price),
          category: newProd.category,
          sub_category: newProd.subCategory,
          image: newProd.images[0],
          images: newProd.images,
          description: newProd.description,
          sizes: newProd.sizes
      }]);
      setNewProd({ name: '', price: '', category: 'Women Ethnic', subCategory: 'Sarees', images: [], description: '', sizes: [] });
      fetchData();
      alert("Product added!");
  };

  const saveUpi = async () => {
      await supabase.from('settings').upsert({ id: 'admin_upi', value: adminUpi });
      alert("UPI ID Saved!");
  };

  const safeParseItems = (items: any) => {
      if (Array.isArray(items)) return items;
      try { return JSON.parse(items); } catch (e) { return []; }
  };

  if (isSplashActive) return (
    <div className="splash-screen" style={{display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', background: 'var(--primary)', color: 'white'}}>
        <h1 style={{fontSize: '3rem', fontWeight: 800}}>KHALSAre</h1>
        <div className="spinner" style={{borderColor: 'white', borderTopColor: 'transparent'}}></div>
    </div>
  );

  return (
    <div className="meesho-app app-shell">
      <header className="app-header">
        <div className="header-top">
          <div className="logo" onClick={() => setView('home')} style={{cursor: 'pointer'}}>KHALSAre</div>
          <div style={{display: 'flex', gap: '15px', alignItems: 'center'}}>
            <div className="lang-switch" onClick={() => setLang(lang === 'ml' ? 'en' : 'ml')}>{t.lang}</div>
            <div onClick={() => setView('cart')} style={{position: 'relative', cursor: 'pointer'}}><CartIcon />{cart.length > 0 && <span className="cart-badge">{cart.length}</span>}</div>
          </div>
        </div>
        {view === 'home' && (
          <div className="search-bar">
            <SearchIcon />
            <input placeholder={t.search} />
          </div>
        )}
      </header>

      <main className="content-area">
        {view === 'home' && (
          <div className="view-transition">
            <div className="shopsy-banner-container" style={{padding: '10px 0', background: '#fff'}}>
               <div className="banner-scroll" style={{display: 'flex', overflowX: 'auto', gap: '10px', padding: '0 15px', scrollSnapType: 'x mandatory'}}>
                  {banners.map(b => (
                      <img key={b.id} src={b.image} style={{minWidth: '90%', height: '160px', borderRadius: '15px', objectFit: 'cover', scrollSnapAlign: 'center'}} alt="Banner" />
                  ))}
               </div>
            </div>

            <div className="category-section" style={{display: 'flex', overflowX: 'auto', padding: '15px', gap: '20px', background: '#fff'}}>
              {CATEGORIES.map(c => (
                <div key={c} className="cat-item" style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px', minWidth: '70px'}}>
                  <div style={{width: '60px', height: '60px', borderRadius: '50%', background: '#f9f9f9', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #eee'}}>
                    <img src={CAT_IMAGES[c] || CAT_IMAGES["All"]} style={{width: '35px'}} alt={c} />
                  </div>
                  <span style={{fontSize: '0.65rem', fontWeight: 600, color: '#555'}}>{c}</span>
                </div>
              ))}
            </div>

            <div className="product-grid" style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', padding: '8px'}}>
              {products.map(p => (
                <div key={p.id} className="product-card" onClick={() => { setSelectedProduct(p); setView('product'); }} style={{background: 'white', borderRadius: '12px', overflow: 'hidden', border: '1px solid #f0f0f0'}}>
                  <img src={p.image} style={{width: '100%', aspectRatio: '3/4', objectFit: 'cover'}} alt={p.name} />
                  <div style={{padding: '10px'}}>
                    <div style={{fontSize: '0.8rem', color: '#666', height: '36px', overflow: 'hidden'}}>{p.name}</div>
                    <div style={{fontSize: '1.1rem', fontWeight: 800}}>₹{p.price}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {view === 'orders' && (
          <div style={{padding: '15px'}}>
            <h2 style={{fontSize: '1.2rem', marginBottom: '15px'}}>എന്റെ ഓർഡറുകൾ</h2>
            <div style={{display: 'flex', gap: '10px', marginBottom: '20px'}}>
                <input placeholder="ഫോൺ നമ്പർ നൽകുക" style={{flex: 1, padding: '12px', borderRadius: '10px', border: '1px solid #ddd'}} value={searchPhone} onChange={e => setSearchPhone(e.target.value)} />
                <button className="btn btn-primary" style={{padding: '12px 20px', borderRadius: '10px'}} onClick={async () => {
                    const { data } = await supabase.from('orders').select('*');
                    setUserOrders(data?.filter(o => o.shipping_address.phoneNumber.includes(searchPhone)) || []);
                }}>തിരയുക</button>
            </div>
            {userOrders.map(o => (
                <div key={o.id} style={{background: 'white', padding: '15px', borderRadius: '12px', marginBottom: '10px', border: '1px solid #eee'}}>
                    <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '10px'}}>
                        <span style={{fontSize: '0.7rem', color: '#888'}}>ID: {o.id.slice(0, 8)}</span>
                        <span style={{background: o.status === 'Cancelled' ? '#ffebee' : '#e8f5e9', color: o.status === 'Cancelled' ? '#d32f2f' : '#2e7d32', padding: '2px 10px', borderRadius: '20px', fontSize: '0.7rem', fontWeight: 800}}>{o.status}</span>
                    </div>
                    {safeParseItems(o.items).map((item: any, idx: number) => (
                        <div key={idx} style={{display: 'flex', gap: '10px', marginBottom: '5px'}}>
                            <img src={item.image} style={{width: '40px', height: '50px', borderRadius: '5px', objectFit: 'cover'}} />
                            <div style={{fontSize: '0.85rem'}}>{item.name} (₹{item.price})</div>
                        </div>
                    ))}
                    <div style={{marginTop: '10px', fontWeight: 800}}>ആകെ: ₹{o.total}</div>
                </div>
            ))}
          </div>
        )}

        {view === 'admin' && !isAdminLoggedIn && (
            <div style={{padding: '40px 20px', textAlign: 'center'}}>
                <div style={{fontSize: '3rem'}}>🕵️‍♂️</div>
                <h3>അഡ്മിൻ പ്രവേശനം</h3>
                <input type="password" placeholder="പാസ്‌വേഡ്" style={{width: '100%', padding: '14px', marginTop: '20px', borderRadius: '10px', border: '1px solid #ddd'}} value={adminPass} onChange={e => setAdminPass(e.target.value)} />
                <button className="btn btn-primary" style={{width: '100%', padding: '15px', marginTop: '15px', borderRadius: '10px'}} onClick={handleAdminLogin}>പ്രവേശിക്കുക</button>
            </div>
        )}

        {view === 'admin' && isAdminLoggedIn && (
          <div style={{padding: '15px', background: '#f8f8f8', minHeight: '100%', overflowY: 'auto'}}>
            <div style={{display: 'flex', gap: '10px', marginBottom: '20px', overflowX: 'auto', paddingBottom: '10px'}}>
                <button onClick={() => setAdminTab('orders')} style={{padding: '10px 20px', borderRadius: '20px', background: adminTab === 'orders' ? 'var(--primary)' : '#fff', color: adminTab === 'orders' ? '#fff' : '#333', border: '1px solid #eee', fontWeight: 800}}>Orders</button>
                <button onClick={() => setAdminTab('products')} style={{padding: '10px 20px', borderRadius: '20px', background: adminTab === 'products' ? 'var(--primary)' : '#fff', color: adminTab === 'products' ? '#fff' : '#333', border: '1px solid #eee', fontWeight: 800}}>Products</button>
                <button onClick={() => setAdminTab('banners')} style={{padding: '10px 20px', borderRadius: '20px', background: adminTab === 'banners' ? 'var(--primary)' : '#fff', color: adminTab === 'banners' ? '#fff' : '#333', border: '1px solid #eee', fontWeight: 800}}>Banners</button>
                <button onClick={() => setAdminTab('settings')} style={{padding: '10px 20px', borderRadius: '20px', background: adminTab === 'settings' ? 'var(--primary)' : '#fff', color: adminTab === 'settings' ? '#fff' : '#333', border: '1px solid #eee', fontWeight: 800}}><GearIcon /></button>
            </div>

            {adminTab === 'orders' && (
                <div>
                    <h4>കസ്റ്റമർ ഓർഡറുകൾ ({orders.length})</h4>
                    {orders.map(o => (
                        <div key={o.id} style={{background: 'white', padding: '15px', borderRadius: '15px', marginBottom: '15px', border: '1px solid #eee'}}>
                            <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '10px'}}>
                                <b>{o.shipping_address.fullName}</b>
                                <span style={{fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 800}}>{o.status}</span>
                            </div>
                            <div style={{display: 'flex', gap: '8px', overflowX: 'auto', marginBottom: '10px'}}>
                                {safeParseItems(o.items).map((item: any, i: number) => (
                                    <img key={i} src={item.image} style={{width: '60px', height: '80px', objectFit: 'cover', borderRadius: '8px'}} />
                                ))}
                            </div>
                            <div style={{fontSize: '0.8rem', marginBottom: '10px'}}>
                                {o.shipping_address.houseNo}, {o.shipping_address.area}, PIN: {o.shipping_address.pincode}<br/>
                                PH: {o.shipping_address.phoneNumber} | Total: <b>₹{o.total}</b>
                            </div>
                            <div style={{display: 'flex', gap: '5px'}}>
                                <button onClick={() => updateOrderStatus(o.id, 'Shipped')} style={{flex: 1, padding: '8px', background: '#e1f5fe', color: '#0288d1', borderRadius: '8px', border: 'none', fontWeight: 700}}>Ship</button>
                                <button onClick={() => updateOrderStatus(o.id, 'Delivered')} style={{flex: 1, padding: '8px', background: '#e8f5e9', color: '#2e7d32', borderRadius: '8px', border: 'none', fontWeight: 700}}>Deliver</button>
                                <button onClick={() => updateOrderStatus(o.id, 'Cancelled')} style={{padding: '8px', background: '#ffebee', color: '#d32f2f', borderRadius: '8px', border: 'none'}}><TrashIcon /></button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {adminTab === 'products' && (
                <div>
                    <h4 style={{display: 'flex', alignItems: 'center', gap: '8px'}}><PlusIcon /> New Product</h4>
                    <div style={{background: 'white', padding: '15px', borderRadius: '15px', border: '1px solid #eee'}}>
                        <div onClick={() => productGalleryRef.current?.click()} style={{width: '100%', height: '100px', border: '2px dashed #ddd', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', overflowX: 'auto', gap: '5px'}}>
                            {newProd.images.length > 0 ? newProd.images.map((img, i) => <img key={i} src={img} style={{height: '80px', borderRadius: '5px'}} />) : "Add Photos"}
                        </div>
                        <input type="file" multiple ref={productGalleryRef} style={{display: 'none'}} onChange={(e) => {
                            const files = Array.from(e.target.files || []);
                            files.forEach(f => {
                                const r = new FileReader();
                                r.onloadend = () => setNewProd(p => ({...p, images: [...p.images, r.result as string]}));
                                r.readAsDataURL(f);
                            });
                        }} />
                        <input placeholder="Item Name" style={{width: '100%', padding: '12px', marginTop: '10px', borderRadius: '8px', border: '1px solid #ddd'}} value={newProd.name} onChange={e => setNewProd({...newProd, name: e.target.value})} />
                        <input placeholder="Price" type="number" style={{width: '100%', padding: '12px', marginTop: '10px', borderRadius: '8px', border: '1px solid #ddd'}} value={newProd.price} onChange={e => setNewProd({...newProd, price: e.target.value})} />
                        <select style={{width: '100%', padding: '12px', marginTop: '10px', borderRadius: '8px', border: '1px solid #ddd'}} value={newProd.category} onChange={e => setNewProd({...newProd, category: e.target.value})}>
                            {Object.keys(CATEGORY_MAP).map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                        <button className="btn btn-primary" style={{width: '100%', padding: '14px', marginTop: '15px', borderRadius: '10px'}} onClick={handleAddProduct}>Save Product</button>
                    </div>
                    
                    <h4 style={{marginTop: '25px'}}>Inventory ({products.length})</h4>
                    {products.map(p => (
                        <div key={p.id} style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px', background: 'white', borderRadius: '10px', marginBottom: '8px', border: '1px solid #eee'}}>
                            <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                                <img src={p.image} style={{width: '40px', height: '50px', objectFit: 'cover', borderRadius: '5px'}} />
                                <div>{p.name.slice(0, 15)}...<br/><span style={{fontSize: '0.7rem'}}>₹{p.price}</span></div>
                            </div>
                            <button onClick={async () => { if(confirm("Delete?")) { await supabase.from('products').delete().eq('id', p.id); fetchData(); }}} style={{background: '#fff1f1', border: 'none', color: '#ff4d4d', padding: '8px', borderRadius: '8px'}}><TrashIcon /></button>
                        </div>
                    ))}
                </div>
            )}

            {adminTab === 'banners' && (
                <div>
                    <h4>Home Banners</h4>
                    <div onClick={() => bannerRef.current?.click()} style={{width: '100%', height: '80px', border: '2px dashed #ddd', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer'}}>
                        <PlusIcon /> Upload Banner
                    </div>
                    <input type="file" ref={bannerRef} style={{display: 'none'}} onChange={handleBannerUpload} />
                    <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginTop: '15px'}}>
                        {banners.map(b => (
                            <div key={b.id} style={{position: 'relative'}}>
                                <img src={b.image} style={{width: '100%', height: '60px', objectFit: 'cover', borderRadius: '8px'}} />
                                <div onClick={async () => { await supabase.from('banners').delete().eq('id', b.id); fetchData(); }} style={{position: 'absolute', top: '-5px', right: '-5px', background: 'red', color: 'white', borderRadius: '50%', width: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px'}}>X</div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {adminTab === 'settings' && (
                <div style={{background: 'white', padding: '20px', borderRadius: '15px'}}>
                    <h4>അഡ്മിൻ സെറ്റിംഗ്‌സ്</h4>
                    <label style={{fontSize: '0.8rem', color: '#666'}}>Admin UPI ID (Payment സ്വീകരിക്കാൻ)</label>
                    <input style={{width: '100%', padding: '12px', marginTop: '5px', borderRadius: '10px', border: '1px solid #ddd'}} value={adminUpi} onChange={e => setAdminUpi(e.target.value)} />
                    <button className="btn btn-primary" style={{width: '100%', padding: '14px', marginTop: '15px', borderRadius: '10px'}} onClick={saveUpi}>Save UPI Settings</button>
                </div>
            )}
            <div style={{height: '100px'}}></div>
          </div>
        )}

        {view === 'product' && selectedProduct && (
            <div className="product-detail view-transition" style={{background: 'white', height: '100%', overflowY: 'auto'}}>
                <div className="detail-header" onClick={() => setView('home')} style={{padding: '15px', display: 'flex', alignItems: 'center', gap: '10px', borderBottom: '1px solid #eee', cursor: 'pointer'}}><ArrowLeftIcon /> ബാക്ക്</div>
                <img src={selectedProduct.image} style={{width: '100%', height: '400px', objectFit: 'contain', background: '#f9f9f9'}} alt={selectedProduct.name} />
                <div style={{padding: '20px'}}>
                   <h2 style={{fontSize: '1.2rem', color: '#555'}}>{selectedProduct.name}</h2>
                   <h1 style={{fontSize: '2rem', fontWeight: 800, margin: '10px 0'}}>₹{selectedProduct.price}</h1>
                   <div style={{marginTop: '20px'}}>
                      <b>Select Size</b>
                      <div style={{display: 'flex', gap: '10px', marginTop: '10px'}}>
                         {['S', 'M', 'L', 'XL', 'FREE'].map(s => (
                             <div key={s} onClick={() => setSelectedSize(s)} style={{padding: '10px 18px', border: `2px solid ${selectedSize === s ? 'var(--primary)' : '#eee'}`, borderRadius: '10px', cursor: 'pointer'}}>{s}</div>
                         ))}
                      </div>
                   </div>
                   <button className="btn btn-primary" style={{width: '100%', padding: '18px', borderRadius: '12px', marginTop: '30px', fontWeight: 800}} onClick={() => handleAddToCart(selectedProduct)}>കാർട്ടിലേക്ക് ചേർക്കുക</button>
                </div>
            </div>
        )}

        {view === 'checkout' && (
          <div style={{padding: '15px'}}>
             <h2 style={{marginBottom: '15px'}}>ഡെലിവറി അഡ്രസ്</h2>
             <div style={{background: 'white', padding: '20px', borderRadius: '15px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)'}}>
              <input placeholder="പൂർണ്ണ നാമം *" style={{width: '100%', padding: '14px', marginBottom: '12px', borderRadius: '10px', border: '1px solid #ddd'}} value={address.fullName} onChange={e => setAddress({...address, fullName: e.target.value})} />
              <input placeholder="ഫോൺ നമ്പർ *" type="tel" style={{width: '100%', padding: '14px', marginBottom: '12px', borderRadius: '10px', border: '1px solid #ddd'}} value={address.phoneNumber} onChange={e => setAddress({...address, phoneNumber: e.target.value})} />
              <input placeholder="വീട്ടുപേര് / നമ്പർ *" style={{width: '100%', padding: '14px', marginBottom: '12px', borderRadius: '10px', border: '1px solid #ddd'}} value={address.houseNo} onChange={e => setAddress({...address, houseNo: e.target.value})} />
              <input placeholder="സ്ഥലം / ഏരിയ *" style={{width: '100%', padding: '14px', marginBottom: '12px', borderRadius: '10px', border: '1px solid #ddd'}} value={address.area} onChange={e => setAddress({...address, area: e.target.value})} />
              <div style={{display: 'flex', gap: '10px', marginBottom: '12px'}}>
                  <input placeholder="പിൻകോഡ് *" type="number" style={{flex: 1, padding: '14px', borderRadius: '10px', border: '1px solid #ddd'}} value={address.pincode} onChange={e => setAddress({...address, pincode: e.target.value})} />
                  <input placeholder="സിറ്റി *" style={{flex: 1, padding: '14px', borderRadius: '10px', border: '1px solid #ddd'}} value={address.city} onChange={e => setAddress({...address, city: e.target.value})} />
              </div>
              <div style={{display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px'}}>
                 <label style={{display: 'flex', alignItems: 'center', gap: '10px', padding: '12px', border: '1px solid #eee', borderRadius: '10px'}}>
                    <input type="radio" checked={paymentMethod === 'COD'} onChange={() => setPaymentMethod('COD')} /> <b>Cash on Delivery (COD)</b>
                 </label>
                 <label style={{display: 'flex', alignItems: 'center', gap: '10px', padding: '12px', border: '1px solid #eee', borderRadius: '10px'}}>
                    <input type="radio" checked={paymentMethod === 'Online'} onChange={() => setPaymentMethod('Online')} /> <b>Online (UPI)</b>
                 </label>
              </div>
              <button className="btn btn-primary" style={{width: '100%', padding: '20px', borderRadius: '12px', fontWeight: 800}} onClick={handlePlaceOrder}>ഓർഡർ കൺഫേം ചെയ്യുക (₹{cart.reduce((a, b) => a + b.price, 0)})</button>
            </div>
          </div>
        )}

        {view === 'cart' && (
          <div style={{padding: '15px'}}>
            <h2 style={{fontSize: '1.4rem', fontWeight: 800}}>കാർട്ട് ({cart.length})</h2>
            {cart.map((item, i) => (
              <div key={i} style={{display: 'flex', gap: '12px', background: 'white', padding: '12px', marginBottom: '10px', borderRadius: '12px', border: '1px solid #eee'}}>
                <img src={item.image} style={{width: '60px', height: '80px', borderRadius: '8px', objectFit: 'cover'}} alt={item.name} />
                <div style={{flex: 1}}>
                  <div style={{fontWeight: 700, fontSize: '0.9rem'}}>{item.name}</div>
                  <div style={{fontWeight: 800, marginTop: '4px', color: 'var(--primary)'}}>₹{item.price}</div>
                </div>
                <button onClick={() => setCart(cart.filter((_, idx) => idx !== i))} style={{background: 'none', border: 'none', color: '#999'}}><TrashIcon /></button>
              </div>
            ))}
            {cart.length > 0 && (
                <button className="btn btn-primary" style={{width: '100%', padding: '18px', borderRadius: '12px', marginTop: '10px'}} onClick={() => setView('checkout')}>ചെക്ക് ഔട്ട്</button>
            )}
          </div>
        )}
      </main>

      <nav className="bottom-nav">
        <div className={`nav-item ${view === 'home' ? 'active' : ''}`} onClick={() => setView('home')}><HomeIcon /><div>ഹോം</div></div>
        <div className={`nav-item ${view === 'orders' ? 'active' : ''}`} onClick={() => setView('orders')}><BellIcon /><div>ഓർഡറുകൾ</div></div>
        <div className={`nav-item ${view === 'cart' ? 'active' : ''}`} onClick={() => setView('cart')} style={{position: 'relative'}}>
            <CartIcon />
            {cart.length > 0 && <span className="cart-badge">{cart.length}</span>}
            <div>കാർട്ട്</div>
        </div>
        <div className={`nav-item ${view === 'profile' || view === 'admin' ? 'active' : ''}`} onClick={() => setView('profile')}><div className={`me-icon ${view === 'profile' || view === 'admin' ? 'active' : ''}`}>K</div><div>അക്കൗണ്ട്</div></div>
      </nav>

      {view === 'profile' && (
        <div className="drawer-overlay" onClick={() => setView('home')} style={{position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000}}>
          <div className="drawer-content" onClick={e => e.stopPropagation()} style={{position: 'absolute', bottom: 0, width: '100%', maxWidth: '500px', background: 'white', padding: '25px', borderTopLeftRadius: '25px', borderTopRightRadius: '25px'}}>
            <h3 style={{marginBottom: '20px', fontSize: '1.2rem', fontWeight: 800}}>അക്കൗണ്ട്</h3>
            <button className="btn btn-outline" style={{width: '100%', marginBottom: '12px', padding: '18px', borderRadius: '12px', border: '1px solid var(--primary)', color: 'var(--primary)', fontWeight: 800}} onClick={() => { setView('admin'); setIsAdminLoggedIn(false); }}>അഡ്മിൻ ഡാഷ്ബോർഡ്</button>
            <button className="btn btn-outline" style={{width: '100%', padding: '18px', borderRadius: '12px', border: '1px solid #ddd', color: '#666', fontWeight: 800}} onClick={() => setView('home')}>അടയ്ക്കുക</button>
          </div>
        </div>
      )}
    </div>
  );
}

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(<App />);
}
