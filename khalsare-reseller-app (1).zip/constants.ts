
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export const CATEGORY_MAP = {
  "Women Ethnic": ["Sarees", "Kurtis", "Lehengas", "Jewellery"],
  "Women Western": ["Dresses", "Tops", "Jeans"],
  "Men": ["Shirts", "T-shirts", "Trousers", "Ethnic Wear"],
  "Kids": ["Boys Clothing", "Girls Clothing", "Toys"],
  "Home & Kitchen": ["Bed Linens", "Kitchen Tools", "Decor"],
  "Electronics": ["Accessories", "Gadgets"]
};

export const CATEGORIES = ["All", ...Object.keys(CATEGORY_MAP)];

export const TRANSLATIONS = {
  en: {
    home: "Home",
    cart: "Cart",
    search: "Search products...",
    categories: "Categories",
    add_cart: "Add to Cart",
    orders: "Orders",
    lang: "മലയാളം"
  },
  ml: {
    home: "ഹോം",
    cart: "കാർട്ട്",
    search: "തിരയുക...",
    categories: "വിഭാഗങ്ങൾ",
    add_cart: "കാർട്ടിലേക്ക്",
    orders: "ഓർഡറുകൾ",
    lang: "English"
  }
};
