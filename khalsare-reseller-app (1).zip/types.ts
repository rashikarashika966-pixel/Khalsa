

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export type View = 'home' | 'product' | 'cart' | 'checkout' | 'admin' | 'orders' | 'profile' | 'community';

// Fix: Added Artifact interface required by ArtifactCard.tsx
export interface Artifact {
  id: string;
  html: string;
  styleName: string;
  status: 'streaming' | 'complete' | 'error';
}

export interface Product {
  id: string;
  name: string;
  category: string;
  subCategory?: string;
  price: number;
  image: string; // Keep for compatibility, will use images[0]
  images?: string[]; // Array of Base64 photos
  description: string;
  sizes?: string[];
  colors?: string[];
  created_at?: string;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  resellerMargin?: number;
}

export type OrderStatus = 'Pending' | 'Shipped' | 'Delivered' | 'Cancelled';

export interface ShippingAddress {
  fullName: string;
  phoneNumber: string;
  houseNo: string;
  area: string;
  pincode: string;
  city: string;
  state: string;
  landmark: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: OrderStatus;
  shippingAddress: ShippingAddress;
  timestamp: number;
}

export type Language = 'en' | 'ml';